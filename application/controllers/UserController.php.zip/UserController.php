<?php

class UserController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
        // action body
        $this->view->form = new Application_Form_Addstudent();

    }

    public function addAction()
    {
        // action body
        $data = $this->getRequest()->getParams();

        if ($_POST['oper'] == 'add') {


            $dev = new Model_Student();
            $dev->name = $data['name'];
            $dev->save();
        } elseif ($_POST['oper'] == 'edit') {

        }
    }

    public function updateAction()
    {
        $data = $this->getRequest()->getParams();

        $id = $data['id'];
        $name = $data['name'];

        $q = Doctrine_Query::create()
            ->update('Model_Student s')
            ->set('s.name', "'$name'")
            ->where("s.id = '$id'");
        $q->execute();

    }

    public function deleteAction()
    {
        // action body
        $data = $this->getRequest()->getParams();
        $id=$data['id'];
        $q = Doctrine_Query::create()
            ->delete('Model_Student s')
            ->where("s.id = $id");
        $q->execute();
    }

    public function jsonAction()
    {
        // action body
        $q = Doctrine_Query::create()
            ->select("s.*")
            ->from("Model_Student s");

        echo json_encode($q->fetchArray());

    }


}













